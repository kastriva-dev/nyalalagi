module.exports=[67660,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_lapor_page_actions_08ef_hc.js.map