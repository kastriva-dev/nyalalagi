1:"$Sreact.fragment"
2:I[25018,["/_next/static/chunks/00gvd_5s9eefy.js","/_next/static/chunks/1i8toyw31zcy7.js"],"default"]
3:I[35949,["/_next/static/chunks/00gvd_5s9eefy.js","/_next/static/chunks/1i8toyw31zcy7.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"RlDwYYjBl4DKZfK4zlIY4"}
