var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1yczblm._.js")
R.c("server/chunks/ssr/1es0_next_dist_esm_build_templates_app-page_03bnroj.js")
R.c("server/chunks/ssr/[root-of-the-server]__1h8cmwo._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0om0lm2._.js")
R.c("server/chunks/ssr/1es0_next_dist_client_components_builtin_global-error_1er8ejh.js")
R.c("server/chunks/ssr/1yd9__next-internal_server_app__global-error_page_actions_0iixyqs.js")
R.m(2029)
module.exports=R.m(2029).exports
