1:"$Sreact.fragment"
2:I[95245,["/_next/static/chunks/1wrc5-3-ulv4l.js","/_next/static/chunks/1i8toyw31zcy7.js","/_next/static/chunks/3kz8tujm6uq1_.js","/_next/static/chunks/0-jzkipk0ppwg.js","/_next/static/chunks/1j5-dhizoyy9e.js","/_next/static/chunks/3bmkndqu0key6.js"],"default"]
3:I[77540,["/_next/static/chunks/1wrc5-3-ulv4l.js","/_next/static/chunks/1i8toyw31zcy7.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/3kz8tujm6uq1_.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0-jzkipk0ppwg.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/1j5-dhizoyy9e.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/3bmkndqu0key6.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"RlDwYYjBl4DKZfK4zlIY4"}
5:null
