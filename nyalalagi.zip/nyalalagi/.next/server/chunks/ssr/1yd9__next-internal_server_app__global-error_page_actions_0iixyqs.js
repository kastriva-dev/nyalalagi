module.exports=[16517,(a,b,c)=>{}];

//# sourceMappingURL=1yd9__next-internal_server_app__global-error_page_actions_0iixyqs.js.map