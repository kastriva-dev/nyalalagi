module.exports=[69476,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app_admin_page_actions_08te_kk.js.map