module.exports=[29190,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app_login_page_actions_1jb_mm2.js.map