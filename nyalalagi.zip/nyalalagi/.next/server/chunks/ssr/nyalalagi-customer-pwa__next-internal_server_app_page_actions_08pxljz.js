module.exports=[99536,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app_page_actions_08pxljz.js.map