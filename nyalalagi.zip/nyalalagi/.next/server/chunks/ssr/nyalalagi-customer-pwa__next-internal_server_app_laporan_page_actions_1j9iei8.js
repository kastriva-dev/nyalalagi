module.exports=[51199,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app_laporan_page_actions_1j9iei8.js.map