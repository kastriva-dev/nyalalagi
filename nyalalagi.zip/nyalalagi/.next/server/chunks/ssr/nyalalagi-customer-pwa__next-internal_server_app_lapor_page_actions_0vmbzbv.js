module.exports=[59366,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app_lapor_page_actions_0vmbzbv.js.map