module.exports=[71812,(a,b,c)=>{}];

//# sourceMappingURL=nyalalagi-customer-pwa__next-internal_server_app__not-found_page_actions_02zbrnj.js.map