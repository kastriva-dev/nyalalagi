globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/RlDwYYjBl4DKZfK4zlIY4/_buildManifest.js",
    "static/RlDwYYjBl4DKZfK4zlIY4/_ssgManifest.js",
    "static/RlDwYYjBl4DKZfK4zlIY4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/42_6na3s-gp4n.js",
    "static/chunks/32fmsn9of9giw.js",
    "static/chunks/1onb81_9vfwqi.js",
    "static/chunks/1yclk4tp-u0zf.js",
    "static/chunks/turbopack-31zsygbq84lvf.js"
  ]
};
